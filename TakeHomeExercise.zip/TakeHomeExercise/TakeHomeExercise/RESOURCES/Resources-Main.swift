//
//  Resources-Main.swift
//  TakeHomeExercise
//
//  Created by Alexey L on 1/29/24.
//

import SwiftUI

struct Resources {
}

