//
//  TakeHomeExerciseApp.swift
//  TakeHomeExercise
//
//  Created by Alexey L on 1/28/24.
//

import SwiftUI

@main
struct TakeHomeExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
